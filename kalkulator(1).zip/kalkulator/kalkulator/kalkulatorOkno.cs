﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Globalization;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace kalkulator
{
    public partial class kalkulatorOkno : Form
    {
        String separator = CultureInfo.CurrentCulture.NumberFormat.NumberDecimalSeparator;
        
        Double resultVal = 0d;
        String operacja = "";
        bool operationPerformed = false;
        public kalkulatorOkno()
        {
            InitializeComponent();
        }

        private void button_Click(object sender, EventArgs e)
        {
            Button button = (Button)sender;

            if (result.Text=="0" || result.Text == "-0" && button.Text!=separator) result.Clear();
            if (operationPerformed)
            {
                result.Clear();
                prev.Text = resultVal + " ";
            }
            operationPerformed = false;
            if (button.Text == separator)
            {
                if (!result.Text.Contains(separator)) result.Text = result.Text + button.Text;
            }
            else result.Text = result.Text + button.Text;

        }

        private void operation(object sender, EventArgs e)
        {
            Button button = (Button)sender;
            operacja = button.Text;
           


            if (result.Text != "" && prev.Text != "")
                switch (operacja)
                {
                    case "+":
                        result.Text = (resultVal + Double.Parse(result.Text)).ToString();

                        break;
                    case "-":
                        result.Text = (resultVal - Double.Parse(result.Text)).ToString();

                        break;
                    case "*":
                        result.Text = (resultVal * Double.Parse(result.Text)).ToString();

                        break;
                    case "/":
                        if (result.Text == "0")
                        {
                            MessageBox.Show("Nie dzieli się przez zero");
                            MessageBox.Show("Deklu");
                            goto blad;
                        }
                        else result.Text = (resultVal / Double.Parse(result.Text)).ToString();

                        break;
                    default:
                        break;
                }
            if(result.Text!="") resultVal = Double.Parse(result.Text);
            blad:
            prev.Text = result.Text;

            operationPerformed = true;
        }

        private void purge(object sender, EventArgs e)
        {
            result.Text = "";
            prev.Text = "";
            resultVal = 0;
            operationPerformed = false;
        }

        private void backspace(object sender, EventArgs e)
        {
            int textLenght = result.Text.Length;
            if (textLenght > 0) result.Text = result.Text.Substring(0, textLenght - 1);
        }

        private void equalizer(object sender, EventArgs e)
        {
            switch (operacja)
            {
                case "+":
                    result.Text = (resultVal + Double.Parse(result.Text)).ToString();
                    operacja = "";
                    break;
                case "-":
                    result.Text = (resultVal - Double.Parse(result.Text)).ToString();
                    operacja = "";

                    break;
                case "*":
                    result.Text = (resultVal * Double.Parse(result.Text)).ToString();
                    operacja = "";

                    break;
                case "/":
                    if (result.Text == "0") {
                        MessageBox.Show("Nie dzieli się przez zero");
                        MessageBox.Show("Deklu");
                        }
                    else result.Text = (resultVal / Double.Parse(result.Text)).ToString();
                    operacja = "";

                    break;
                default:
                    break;
            }
            resultVal = 0;

        }

        private void result_KeyPress(object sender, KeyPressEventArgs e)
        {
            String separator = CultureInfo.CurrentCulture.NumberFormat.NumberDecimalSeparator;

            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != ',') && (e.KeyChar != '.'))
            {
                e.Handled = true;
            }

            if ((e.KeyChar == ',') && ((sender as TextBox).Text.IndexOf(',') > -1))
            {
                e.Handled = true;
            }
            else if ((e.KeyChar == '.') && ((sender as TextBox).Text.IndexOf('.') > -1))
            {
                e.Handled = true;
            }
        }

        private void zmianaZnaku(object sender, EventArgs e)
        {
            int textLenght = result.Text.Length;

            if (textLenght > 0)
            {
                if ((result.Text[0]).Equals('-')) result.Text = result.Text.Substring(1, textLenght - 1);
                else result.Text = "-" + result.Text;
            }
            else result.Text = "-" + result.Text;
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
